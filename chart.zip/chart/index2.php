<?php  
    include("conexion.php");
    if(isset($_POST["idPregunta"]))
{
    $query = "
    SELECT p.pregunta,r.idDatos,o.descOpcion,count(*) as contando from preguntas p,respuesta r, opciones o where p.idPregunta = r.idPregunta and r.idOpcion=o.idOpcion and r.idPregunta ='".$_POST["idPregunta"]."' group by r.idOpcion";  
    $statement = $pdo->prepare($query); 
    $statement->execute();
    $result = $statement->fetchAll();
}
?>


           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['idOpcion', 'contando'],  
                          <?php  
                          foreach($result as $row)  
                          {  
                               echo "['".$row["descOpcion"]."', ".$row["contando"]."],";  
                          } 
                          ?>  
                     ]);  
                var options = {  
                      title: 'Estadística general Pregunta:  <?php echo $row["pregunta"]?>',  
                      //is3D:true,  
                      pieHole: 0.4  
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           }  
           </script>  

           <div style="width:900px;">  
           
                
                <div id="piechart" style="width: 900px; height: 500px;">
          
               
                </div>  
           </div>  
