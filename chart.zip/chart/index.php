<?php  
//index.php
include("conexion.php");

$query = "SELECT idPregunta,pregunta FROM preguntas GROUP BY pregunta ORDER BY idPregunta ";
$statement = $pdo->prepare($query);
$statement->execute();
$result = $statement->fetchAll();

?>  

<!DOCTYPE html>  
<html>  
    <head>  
        <title>Probando</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script> 
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    </head>  
    <body> 
        <br /><br />
        <div class="container">  
            <h3 style="text-align:center">ESTADISTICA DE RESPUESTAS GENERALES</h3>  
            <br />  
            <form method="POST" action="index.php">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-9">
                        <select name="idPregunta" class="form-control" id="idPregunta">
                                <option value="">Seleciona Pregunta</option>
                            <?php
                            foreach($result as $row)
                            {
                                echo '<option value="'.$row["idPregunta"].'">'.$row["pregunta"].'</option>';
                            }
                            ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                        <input type="submit" value="Ver estadística">
                            
                        </div>

                    </div>

                 <?php include('index2.php')?>   
                </div>
                        
                </form>    
            </div>
        </div>  
    </body>  
</html>